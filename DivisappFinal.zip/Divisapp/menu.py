import crud
import core
import os

def mprincipal():
        IsMenuActivate=True
        while IsMenuActivate==True:
            os.system('cls')
            print("****************************************") 
            print("*           ¡Menu Principal!           *")
            print("****************************************\n")
            print("1.Renovar tus datos\n2.Ingresar divisapp\n3.Salir")
            op=int(input())
            print(op)
    #-------------------------------------------------------------------------------------#
            if op==1:
                crud.AddItemDicc()
                dircontacto=core.LoadInfo('contacto.json')
    #-------------------------------------------------------------------------------------#
            elif op==2:
                import Cambio
                dircontacto=core.LoadInfo('contacto.json')
    #-------------------------------------------------------------------------------------#
            elif op==3:
                    rta=input("¿Seguro de salir del programa? S o N")
                    if rta.upper()=="S":
                        break
                    elif rta.upper()=="N":
                        IsMenuActivate=True
                        dircontacto=core.LoadInfo('contacto.json')
