import core as cr
import os

def AddItemDicc():
            dicc={}
            dicDir={}
            os.system('cls')

            print("****************************************") 
            print("*                                      *")
            print("*         ¡ Registrate aquí !          *")
            print("*                                      *")
            print("****************************************")

            nombre=input("Nombre: ")
            email=input ("Email : ")
            movil=input ("Movil : ")
            edadd=input("Edad  : ")
            os.system("pause")
            os.system('cls')
  
            contacto={
                    "nombre":nombre,
                    "email":email,
                    "movil":movil,
                    "edad":edadd
                    }
            cr.editarInfo("contacto.json", contacto)