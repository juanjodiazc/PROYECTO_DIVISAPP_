import crud
import core
import os

agenda=[]
dircontacto={"data":[]}
IsMenuActivate=True


###########################################################################################

###########################################################################################
if __name__ == "__main__":
    os.system('cls')
    if(core.checkFile('contacto.json')):
        dircontacto=core.LoadInfo('contacto.json')
    else:
        core.crearInfo('contacto.json',dircontacto)
    while IsMenuActivate==True:
        os.system('cls')
        print("***********************************************") 
        print("*                                             *")
        print("*         ¡Bienvenidos a Divisapp!            *")
        print("* En nuestro programa podra convertir el COP  *")
        print("* a las monedas mas importantes del mercado.  *")
        print("*                                             *")
        print("*********************************************** \n")

        rta=input("¿Ya se encuentra registrado en Divisapp? S o N")
        if rta.upper()=="S" or rta.upper()=="s":
            import menu
            menu.mprincipal()
            break
        elif rta.upper()=="N" or rta.upper()=="n":
            crud.AddItemDicc()
            dircontacto=core.LoadInfo('contacto.json')
###########################################################################################

###########################################################################################