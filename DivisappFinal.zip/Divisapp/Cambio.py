import tkinter as tk
from tkinter import ttk


def convertir_divs():
    pesos_c = float(caja_conv_colombianos.get())
    conv_dolares = pesos_c * 0.00021
    conv_euro = pesos_c* 0.00020
    conv_LB = pesos_c* 0.00018
    conv_YenJ= pesos_c* 0.02899



#Etiquetas
    Conv_dolares.config(text=f"Pesos colombia en Dolares:{conv_dolares} ")
    Conv_euro.config(text=f"Pesos colombia en Euros: {conv_euro} " )
    Conv_LB.config(text=f"Pesos colombia en Libras Esterlinas:{conv_LB} ")
    Conv_YenJ.config(text=f"Pesos colombia en Yenes: {conv_YenJ} " )

ventana = tk.Tk()
ventana.title("Conversor de divisas")
ventana.config(width=400, height=300)


#Etiqueta
Bienvenida = ttk.Label(text=f"******** Bienvenido a Divisapp ********")
Bienvenida.place(x=20, y=10)

conv_colombianos = ttk.Label(text="Pesos colombianos --> ")
conv_colombianos.place(x=20, y=50)

#Caja
caja_conv_colombianos = ttk.Entry()
caja_conv_colombianos.place(x=150,y=50,width=60)

#Botón
boton_convertir = ttk.Button(text="Convertir", command = convertir_divs)
boton_convertir.place(x=20,y=70)

#Dolares
Conv_dolares = ttk.Label(text="Valor en Dolares --> n/a")
Conv_dolares.place(x=20, y=140)

#Euros
Conv_euro = ttk.Label(text="Valor en Euros --> n/a")
Conv_euro.place(x=20, y=160)

#Libras esterlinas
Conv_LB = ttk.Label(text="Valor en Libras Esterlinas --> n/a")
Conv_LB.place(x=20, y=180)

#Yenes
Conv_YenJ = ttk.Label(text="Valor en Yenes --> n/a")
Conv_YenJ.place(x=20, y=200)


ventana.mainloop()
